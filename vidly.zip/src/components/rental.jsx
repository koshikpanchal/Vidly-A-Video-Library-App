import React from "react";

const Rental = () => {
  return (
    <div>
      <h1>Rental</h1>
    </div>
  );
};

export default Rental;

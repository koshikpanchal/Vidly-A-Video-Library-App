import "./App.css";
import Movie from "./components/movies";

function App() {
  return (
    <main className="container">
      <Movie></Movie>
    </main>
  );
}

export default App;
